#include <stdio.h>
#include <stdint.h>

#define IO_BLOCK_SIZE 16
#define IO_MAX_NUM_CHANNEL 8

typedef enum { FL, FR, FC, LFE, BL, BR, SL, SR } IO_remap;

extern double IO_sampleBuffer[IO_MAX_NUM_CHANNEL][IO_BLOCK_SIZE];
extern uint8_t IO_outputChannelMask;

void IO_open(char* argv[], uint8_t outChs, IO_remap* remap);
void IO_readBlock();
void IO_writeBlock();
uint32_t IO_getTotalNumberOfBlocks();
void IO_close();
