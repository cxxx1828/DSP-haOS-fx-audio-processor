#include <stdio.h>
#include <stdint.h>

void FAS_processBrick(uint32_t size);
