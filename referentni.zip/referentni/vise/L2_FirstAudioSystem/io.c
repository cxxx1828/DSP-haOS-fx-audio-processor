#include <stdio.h>
#include <stdint.h>
#include "io.h"
#include "wavhdr.h"

double IO_sampleBuffer[IO_MAX_NUM_CHANNEL][IO_BLOCK_SIZE];
uint8_t IO_outputChannelMask;

static FILE* wavInput = NULL;
static FILE* wavOutput = NULL;
static char wavInputName[256];
static char wavOutputName[256];
static WavHeader inputWavHeader;
static WavHeader outputWavHeader;
static IO_remap outputRemap[IO_MAX_NUM_CHANNEL];

static uint8_t isActiveOutputChannel(uint8_t ch)
{
	return IO_outputChannelMask & (1 << ch);
}

void IO_open(char* argv[], uint8_t outChs, IO_remap* remap)
{
	// Init channel buffers
	//-------------------------------------------------
	for (int32_t i = 0; i < IO_MAX_NUM_CHANNEL; i++)
	{
		memset(&IO_sampleBuffer[i], 0, IO_BLOCK_SIZE);
	}

	// Open input and output wav files
	//-------------------------------------------------
	strcpy(wavInputName, argv[1]);
	wavInput = WavHeader_Fopen(wavInputName, "rb");
	strcpy(wavOutputName, argv[2]);
	wavOutput = WavHeader_Fopen(wavOutputName, "wb");

	// Read input wav header
	//-------------------------------------------------
	WavHeader_Read(wavInput, &inputWavHeader);

	// Set up output WAV header
	//-------------------------------------------------
	memcpy(&outputWavHeader, &inputWavHeader, sizeof(WavHeader));
	
	if(outChs) outputWavHeader.fmt.numChannels = outChs;
	else outputWavHeader.fmt.numChannels = inputWavHeader.fmt.numChannels;

	int32_t oneChannelSubChunk2Size = inputWavHeader.data.subChunk2Size / inputWavHeader.fmt.numChannels;
	int32_t oneChannelByteRate = inputWavHeader.fmt.byteRate / inputWavHeader.fmt.numChannels;
	int32_t oneChannelBlockAlign = inputWavHeader.fmt.blockAlign / inputWavHeader.fmt.numChannels;

	outputWavHeader.data.subChunk2Size = oneChannelSubChunk2Size * outputWavHeader.fmt.numChannels;
	outputWavHeader.fmt.byteRate = oneChannelByteRate * outputWavHeader.fmt.numChannels;
	outputWavHeader.fmt.blockAlign = oneChannelBlockAlign * outputWavHeader.fmt.numChannels;

	// Write output WAV header to file
	//-------------------------------------------------
	WavHeader_Write(wavOutput, &outputWavHeader);

	memcpy(outputRemap, remap, outputWavHeader.fmt.numChannels * sizeof(IO_remap));
}

uint32_t IO_getTotalNumberOfBlocks()
{
	int32_t iNumSamples = inputWavHeader.data.subChunk2Size / (inputWavHeader.fmt.numChannels * inputWavHeader.fmt.bitsPerSample / 8);
	int32_t iModuloSamples = (iNumSamples / IO_BLOCK_SIZE) % IO_BLOCK_SIZE;
	int32_t iModuloBlocks = ( iModuloSamples / IO_BLOCK_SIZE) + 1;
	return (iNumSamples / IO_BLOCK_SIZE);
}

void IO_readBlock()
{
	int32_t sample;
	int32_t bytesPerSample = inputWavHeader.fmt.bitsPerSample / 8;
	const double SAMPLE_SCALE = -(double)(1U << 31);		//2^31

	for (int32_t j = 0; j < IO_BLOCK_SIZE; j++)
	{
		for (int32_t k = 0; k < 2; k++) // stereo input fixed
		{
			fread(&sample, bytesPerSample, 1, wavInput);
			sample = sample << (32 - inputWavHeader.fmt.bitsPerSample);		// force signextend
			IO_sampleBuffer[k][j] = sample / SAMPLE_SCALE;					// scale sample to 1.0/-1.0 range
		}
	}
}

void IO_writeBlock()
{
	int32_t sample;
	int32_t bytesPerSample = outputWavHeader.fmt.bitsPerSample / 8;
	const double SAMPLE_SCALE = -(double)(1U << 31);		//2^31


	for (int32_t j = 0; j < IO_BLOCK_SIZE; j++)
	{
		for (int32_t k = 0; k < outputWavHeader.fmt.numChannels; k++)
		{
			sample = 0;
			if (isActiveOutputChannel(outputRemap[k]))
			{
				sample = IO_sampleBuffer[outputRemap[k]][j] * SAMPLE_SCALE;	// crude, non-rounding
				sample = sample >> (32 - outputWavHeader.fmt.bitsPerSample);
			}
			fwrite(&sample, bytesPerSample, 1, wavOutput);
		}
	}
}

void IO_close()
{
	// Close files
	//-------------------------------------------------
	fclose(wavInput);
	fclose(wavOutput);
}