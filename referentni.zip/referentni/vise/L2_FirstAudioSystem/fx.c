﻿#include "fx.h"
#include "io.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define BLOCK_SIZE IO_BLOCK_SIZE
#define sampleBuffer IO_sampleBuffer
#define NUM_CHANNELS 6
#define SAMPLE_RATE 48000

static FX_ControlPanel moduleControl;

#define NTAPS 31 
#define DBUFSIZE 640
#define MAX_DELAY_SAMPLES 22000  // za 450ms @ 48kHz + margin

// Gain vrednosti u linearnoj skali
static const double GAIN_CH0_PRE = 0.81283;    // -1.8 dB
static const double GAIN_CH0_POST = 0.87096;   // -1.2 dB
static const double GAIN_CH1_PRE = 0.79433;    // -2.0 dB
static const double GAIN_CH1_POST = 0.77426;   // -2.2 dB

// Filter koeficijenti za CH1-CH5 (za cutoff 2k, 3k, 4k, 5k)
static double lpf2kHz_coeffs[NTAPS] =
{
    -0.00293477270045858870,
    -0.00288096430204124940,
    -0.00250016237760415690,
    -0.00164589844498685530,
    -0.00013456384194181242,
    0.00225884205157718140,
    0.00580400571775908230,
    0.01081700734517632700,
    0.01765966375633795700,
    0.02673557015223622000,
    0.03848174902364159100,
    0.05335467351374602300,
    0.07180932214316887400,
    0.09426986305243344200,
    0.12109058458285790000,
    0.13563016065619612000,
    0.12109058458285790000,
    0.09426986305243344200,
    0.07180932214316887400,
    0.05335467351374602300,
    0.03848174902364159100,
    0.02673557015223622000,
    0.01765966375633795700,
    0.01081700734517632700,
    0.00580400571775908230,
    0.00225884205157718140,
    -0.00013456384194181242,
    -0.00164589844498685530,
    -0.00250016237760415690,
    -0.00288096430204124940,
    -0.00293477270045858870
};

static double lpf3kHz_coeffs[NTAPS] =
{
    -0.00105106340607596220,
    -0.00170346888080965400,
    -0.00250624192866901340,
    -0.00339431573437104200,
    -0.00422212099590341550,
    -0.00472444069729934920,
    -0.00446861323138686780,
    -0.00280012215560185900,
    0.00121378071889749130,
    0.00883416031353021630,
    0.02168127068667904300,
    0.04172769649713474500,
    0.07122907943774888000,
    0.11256174105687924000,
    0.16793187751543467000,
    0.19938156160762566000,
    0.16793187751543467000,
    0.11256174105687924000,
    0.07122907943774888000,
    0.04172769649713474500,
    0.02168127068667904300,
    0.00883416031353021630,
    0.00121378071889749130,
    -0.00280012215560185900,
    -0.00446861323138686780,
    -0.00472444069729934920,
    -0.00422212099590341550,
    -0.00339431573437104200,
    -0.00250624192866901340,
    -0.00170346888080965400,
    -0.00105106340607596220
};

static double lpf4kHz_coeffs[NTAPS] =
{
    0.00023788185274493161,
    0.00014732315999688281,
    -0.00012610517776346129,
    -0.00068427605436556342,
    -0.00162403770285430670,
    -0.00298395274470884650,
    -0.00464731383860926030,
    -0.00618683792099326490,
    -0.00664136791959670480,
    -0.00422852529657953470,
    0.00397624012568426490,
    0.02232048518544594800,
    0.05667994398862042500,
    0.11417521732532962000,
    0.20220642969938624000,
    0.25475779063652526000,
    0.20220642969938624000,
    0.11417521732532962000,
    0.05667994398862042500,
    0.02232048518544594800,
    0.00397624012568426490,
    -0.00422852529657953470,
    -0.00664136791959670480,
    -0.00618683792099326490,
    -0.00464731383860926030,
    -0.00298395274470884650,
    -0.00162403770285430670,
    -0.00068427605436556342,
    -0.00012610517776346129,
    0.00014732315999688281,
    0.00023788185274493161
};

static double lpf5kHz_coeffs[NTAPS] =
{
    0.00008857651266302499,
    0.00018563654770944524,
    0.00029705790434555150,
    0.00035639479549170490,
    0.00022408277442446719,
    -0.00032666317820101296,
    -0.00157705390053453120,
    -0.00372405359560962780,
    -0.00655228341240485060,
    -0.00882463321284275050,
    -0.00733706812629941580,
    0.00429065592013054730,
    0.03675249953744918300,
    0.10535216347841343000,
    0.22811515202438210000,
    0.30535907186176536000,
    0.22811515202438210000,
    0.10535216347841343000,
    0.03675249953744918300,
    0.00429065592013054730,
    -0.00733706812629941580,
    -0.00882463321284275050,
    -0.00655228341240485060,
    -0.00372405359560962780,
    -0.00157705390053453120,
    -0.00032666317820101296,
    0.00022408277442446719,
    0.00035639479549170490,
    0.00029705790434555150,
    0.00018563654770944524,
    0.00008857651266302499
};

// Filter history buffers za sve kanale
static double filter_history[6][NTAPS];

// FIR implementacija
static double fir(double input, double* coeffs, double* history, unsigned int ntaps)
{
    int i;
    double ret = 0;

    // Pomeranje delay line
    for (i = ntaps - 2; i >= 0; i--)
    {
        history[i + 1] = history[i];
    }

    // Čuvanje inputa na početku delay line
    history[0] = input;

    // FIR kalkulacija
    for (i = 0; i < ntaps; i++)
    {
        ret += coeffs[i] * history[i];
    }

    return ret;
}

// Delay state structure
typedef struct
{
    double* delayBuffer;
    double* bufferEndPointer;
    double* readPointer;
    double* writePointer;
    int delay;
    int bufferSize;
} DelayState;

// Delay buffers za svaki kanal
static DelayState channel_delay_state[6];
static double channel_delay_buffer[6][MAX_DELAY_SAMPLES];

// Delay implementacija
static void delayInit(DelayState* delayState, double* delayBuffer, int delayBufLen, int delay)
{
    delayState->delayBuffer = delayBuffer;
    delayState->bufferEndPointer = delayState->delayBuffer + delayBufLen;
    delayState->writePointer = delayState->delayBuffer;
    delayState->delay = delay;
    delayState->bufferSize = delayBufLen;

    // Postavi read pointer unazad za delay uzoraka
    delayState->readPointer = delayState->writePointer - delay;

    // Ako je readPointer ispod početka buffera, wrap-uj
    if (delayState->readPointer < delayState->delayBuffer) {
        delayState->readPointer += delayBufLen;
    }

    // Inicijalizuj buffer na 0
    for (int i = 0; i < delayBufLen; i++) {
        delayBuffer[i] = 0.0;
    }
}

static double applyDelay(double input, DelayState* delayState)
{
    if (!delayState->delayBuffer) return input;

    // Upisi u buffer
    *delayState->writePointer = input;
    delayState->writePointer++;

    // Wrap write pointer
    if (delayState->writePointer >= delayState->bufferEndPointer) {
        delayState->writePointer = delayState->delayBuffer;
    }

    // Pročitaj iz buffera
    double ret = *delayState->readPointer;
    delayState->readPointer++;

    // Wrap read pointer
    if (delayState->readPointer >= delayState->bufferEndPointer) {
        delayState->readPointer = delayState->delayBuffer;
    }

    return ret;
}

// Add limiter funkcija
static double add(double input0, double input1)
{
    double ret = input0 + input1;
    if (ret >= 1.0) ret = 0.99999999;
    if (ret < -1.0) ret = -1.0;
    return ret;
}

// Funkcija za dobijanje koeficijenata na osnovu selektora
static double* getFilterCoeffs(int filter_select)
{
    switch (filter_select) {
    case 0: return lpf2kHz_coeffs;
    case 1: return lpf3kHz_coeffs;
    case 2: return lpf4kHz_coeffs;
    case 3: return lpf5kHz_coeffs;
    default: return lpf4kHz_coeffs;
    }
}

// Inicijalizacija delay-a za sve kanale
static void initCH0Delays()
{
    const int delay_samples_table[4] = {
        0,                      // 0ms
        (int)(SAMPLE_RATE * 0.150),   // 150ms = 7200 samples
        (int)(SAMPLE_RATE * 0.300),   // 300ms = 14400 samples
        (int)(SAMPLE_RATE * 0.450)    // 450ms = 21600 samples
    };

    for (int ch = 0; ch < 6; ch++) {
        // Proveri da li je kanal enable-ovan
        if (!moduleControl.channel_enable[ch]) continue;

        // Dobij delay vrednost iz tabele
        int delay_select = moduleControl.ch0_delay_select[ch];
        if (delay_select < 0 || delay_select > 3) {
            delay_select = 0; // default na 0ms ako je nevalidan
        }

        int delay_samples = delay_samples_table[delay_select];

        // Inicijalizuj delay za ovaj kanal
        delayInit(&channel_delay_state[ch], channel_delay_buffer[ch],
            MAX_DELAY_SAMPLES, delay_samples);

        printf("Channel %d: CH0 delay = %d samples (%d ms)\n",
            ch, delay_samples, delay_select * 150);
    }
}

// FX implementacija
void FX_init(FX_ControlPanel* controlsInit)
{
    // Kopiranje kontrola
    memcpy(&moduleControl, controlsInit, sizeof(FX_ControlPanel));

    // Inicijalizacija delay-a za sve kanale
    initCH0Delays();

    // Reset filter history
    memset(filter_history, 0, sizeof(filter_history));
}

void FX_processBlock()
{
    if (!moduleControl.on) return;

    static int block_counter = 0;
    static const int MAX_BLOCKS = 100865;  // HaOS limit

    if (block_counter >= MAX_BLOCKS) {
        return;
    }

    block_counter++;

    for (int32_t i = 0; i < BLOCK_SIZE; i++) {
        // Procesiranje svih 6 kanala
        for (int ch = 0; ch < 6; ch++) {
            if (!moduleControl.channel_enable[ch]) continue;

            // Originalni signali za ovaj kanal
            double ch0_input = sampleBuffer[0][i]; // Original CH0 (isti za sve kanale)
            double ch1_input = sampleBuffer[1][i]; // Original CH1 (isti za sve kanale)

            // OBRADA CH0 za ovaj kanal
            double processed_ch0;
            if (moduleControl.ch0_processing[ch]) {
                // Kompletna obrada: -1.8dB -> delay -> -1.2dB
                processed_ch0 = ch0_input * GAIN_CH0_PRE;
                processed_ch0 = applyDelay(processed_ch0, &channel_delay_state[ch]);
                processed_ch0 = processed_ch0 * GAIN_CH0_POST;
            }
            else {
                // Samo gain: -1.8dB
                processed_ch0 = ch0_input * GAIN_CH0_PRE;
            }

            // OBRADA CH1 za ovaj kanal: -2.0dB -> filter -> -2.2dB
            double processed_ch1 = ch1_input * GAIN_CH1_PRE;

            // Primeri odgovarajućeg FIR filtera
            int filter_select = moduleControl.ch1_filter_select[ch];
            double* coeffs = getFilterCoeffs(filter_select);
            processed_ch1 = fir(processed_ch1, coeffs, filter_history[ch], NTAPS);

            processed_ch1 = processed_ch1 * GAIN_CH1_POST;

            // SABIRANJE: obrađeni CH1 + obrađeni CH0
            sampleBuffer[ch][i] = add(processed_ch1, processed_ch0);
        }
    }
}

// Funkcija za parsiranje argumenata komandne linije
FX_ControlPanel FX_parseArguments(int argc, char* argv[])
{
    FX_ControlPanel config;

    // Podrazumevane vrednosti
    config.on = 1;

    // Podrazumevano svi kanali enable-ovani
    for (int i = 0; i < 6; i++) {
        config.channel_enable[i] = 1;
        config.ch0_delay_select[i] = 0;        // 0ms delay za sve
        config.ch0_processing[i] = 1;          // kompletan processing za sve
        config.ch1_filter_select[i] = 2;       // 4kHz za sve
    }

    // Parsiranje argumenata
    for (int i = 3; i < argc; i++) {
        printf("Parsing arg %d: %s\n", i, argv[i]);

        // Filter za CH1 u određenom kanalu
        if (strcmp(argv[i], "--filter") == 0 && i + 2 < argc) {
            int ch = atoi(argv[++i]);
            int filter = atoi(argv[++i]);
            if (ch >= 0 && ch < 6 && filter >= 0 && filter <= 3) {
                config.ch1_filter_select[ch] = filter;
                printf("  Set channel %d CH1 filter to %d\n", ch, filter);
            }
        }
        // Delay za CH0 u određenom kanalu
        else if (strcmp(argv[i], "--ch0-delay") == 0 && i + 2 < argc) {
            int ch = atoi(argv[++i]);
            int delay = atoi(argv[++i]);
            if (ch >= 0 && ch < 6 && delay >= 0 && delay <= 3) {
                config.ch0_delay_select[ch] = delay;
                printf("  Set channel %d CH0 delay to %d\n", ch, delay);
            }
        }
        // Processing za CH0 u određenom kanalu
        else if (strcmp(argv[i], "--ch0-processing") == 0 && i + 2 < argc) {
            int ch = atoi(argv[++i]);
            int mode = atoi(argv[++i]);
            if (ch >= 0 && ch < 6) {
                config.ch0_processing[ch] = mode ? 1 : 0;
                printf("  Set channel %d CH0 processing to %s\n", ch, mode ? "full" : "gain only");
            }
        }
        // Skraćene komande za sve kanale
        else if (strcmp(argv[i], "--all-filters") == 0 && i + 1 < argc) {
            int filter = atoi(argv[++i]);
            if (filter >= 0 && filter <= 3) {
                for (int ch = 0; ch < 6; ch++) {
                    config.ch1_filter_select[ch] = filter;
                }
                printf("  Set ALL channels CH1 filter to %d\n", filter);
            }
        }
        else if (strcmp(argv[i], "--all-ch0-delay") == 0 && i + 1 < argc) {
            int delay = atoi(argv[++i]);
            if (delay >= 0 && delay <= 3) {
                for (int ch = 0; ch < 6; ch++) {
                    config.ch0_delay_select[ch] = delay;
                }
                printf("  Set ALL channels CH0 delay to %d\n", delay);
            }
        }
        else if (strcmp(argv[i], "--all-ch0-processing") == 0 && i + 1 < argc) {
            int mode = atoi(argv[++i]);
            for (int ch = 0; ch < 6; ch++) {
                config.ch0_processing[ch] = mode ? 1 : 0;
            }
            printf("  Set ALL channels CH0 processing to %s\n", mode ? "full" : "gain only");
        }
        // Enable/disable kanala
        else if (strcmp(argv[i], "--disable-channel") == 0 && i + 1 < argc) {
            int ch = atoi(argv[++i]);
            if (ch >= 0 && ch < 6) {
                config.channel_enable[ch] = 0;
                printf("  Disabled channel %d\n", ch);
            }
        }
        else if (strcmp(argv[i], "--enable-channel") == 0 && i + 1 < argc) {
            int ch = atoi(argv[++i]);
            if (ch >= 0 && ch < 6) {
                config.channel_enable[ch] = 1;
                printf("  Enabled channel %d\n", ch);
            }
        }
        else if (strcmp(argv[i], "--help") == 0) {
            printf("Usage: %s input.wav output.wav [options]\n", argv[0]);
            printf("Options:\n");
            printf("  --filter CH TYPE       Set CH1 filter for channel CH (0-5)\n");
            printf("                         TYPE: 0=2kHz, 1=3kHz, 2=4kHz, 3=5kHz\n");
            printf("  --ch0-delay CH DELAY   Set CH0 delay for channel CH (0-5)\n");
            printf("                         DELAY: 0=0ms, 1=150ms, 2=300ms, 3=450ms\n");
            printf("  --ch0-processing CH M  Set CH0 processing for channel CH (0-5)\n");
            printf("                         M: 0=samo gain, 1=kompletan processing\n");
            printf("  --all-filters TYPE     Set ALL channels CH1 filter to TYPE\n");
            printf("  --all-ch0-delay DELAY  Set ALL channels CH0 delay to DELAY\n");
            printf("  --all-ch0-processing M Set ALL channels CH0 processing to M\n");
            printf("  --disable-channel CH   Disable channel CH (0-5)\n");
            printf("  --enable-channel CH    Enable channel CH (0-5)\n");
            printf("  --help                 Show this help\n");
            printf("\nExamples:\n");
            printf("  %s in.wav out.wav --filter 1 0 --ch0-delay 1 2 --ch0-processing 1 1\n", argv[0]);
            printf("  %s in.wav out.wav --all-filters 2 --all-ch0-delay 1\n", argv[0]);
            exit(0);
        }
        else {
            printf("Warning: Unknown argument: %s\n", argv[i]);
        }
    }

    // Debug ispis
    printf("\nFinal configuration:\n");
    printf("Channel | Enabled | CH0 Delay | CH0 Processing | CH1 Filter\n");
    printf("--------|---------|-----------|----------------|-----------\n");
    for (int i = 0; i < 6; i++) {
        const char* delay_str[] = { "0ms", "150ms", "300ms", "450ms" };
        const char* filter_str[] = { "2kHz", "3kHz", "4kHz", "5kHz" };

        printf("   %d    |    %c    |   %6s  |      %s       |   %5s\n",
            i,
            config.channel_enable[i] ? 'Y' : 'N',
            delay_str[config.ch0_delay_select[i]],
            config.ch0_processing[i] ? "Full" : "Gain",
            filter_str[config.ch1_filter_select[i]]);
    }
    printf("\n");

    return config;
}