#include "fas.h"
#include "io.h"

extern double* sampleBuffer[];

void FAS_init()
{

}

void FAS_processBrick(uint32_t size)
{
	for (int32_t i = 0; i < size; i++)
	{
		IO_sampleBuffer[0][i] = IO_sampleBuffer[0][i] * 0.5;
		IO_sampleBuffer[1][i] = IO_sampleBuffer[1][i] * 0.25;
	}
}