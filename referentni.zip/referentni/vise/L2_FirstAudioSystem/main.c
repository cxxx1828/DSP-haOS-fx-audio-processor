﻿#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "wavhdr.h"
#include "io.h"
#include "fx.h"

int main(int argc, char* argv[])
{
    // Provera minimalnog broja argumenata
    if (argc < 3) {
        printf("Usage: %s input.wav output.wav [options]\n", argv[0]);
        printf("Use --help for more information\n");
        return 1;
    }

    // Parsiranje argumenata za FX
    FX_ControlPanel fx_config = FX_parseArguments(argc, argv);


    // Izračunaj broj enable-ovanih kanala
    int enabled_channels = 0;
    for (int i = 0; i < 6; i++) {
        if (fx_config.channel_enable[i]) {
            enabled_channels++;
        }
    }

    printf("Processing with %d enabled channels\n", enabled_channels);

    // Inicijalizacija IO
    IO_remap remap[IO_MAX_NUM_CHANNEL] = { FL, FR, FC, LFE, BL, BR, SL, SR };
    IO_outputChannelMask = 0b00111111;

    char* io_argv[3] = { argv[0], argv[1], argv[2] };
    IO_open(io_argv, enabled_channels, remap);

    
    FX_init(&fx_config);

    // Processing loop

    uint32_t total_blocks = IO_getTotalNumberOfBlocks();
    //printf("Processing %d blocks...\n", total_blocks);

    for (int32_t i = 0; i < IO_getTotalNumberOfBlocks(); i++)
    {
        IO_readBlock();
        FX_processBlock();
        IO_writeBlock();

        //// Progress indicator
        //if (i % 100 == 0) {
        //    printf("Processed %d/%d blocks\r", i, total_blocks);
        //    fflush(stdout);
        //}
    }

    //printf("\nProcessing complete!\n");

    // System de-initialization
    IO_close();

    return 0;
}